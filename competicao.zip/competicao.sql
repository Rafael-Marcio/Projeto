-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3310
-- Tempo de geração: 02-Fev-2024 às 20:37
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `competicao`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `competicao`
--

CREATE TABLE `competicao` (
  `idCompeticao` int(11) NOT NULL,
  `NomeCompeticao` varchar(45) DEFAULT NULL,
  `InicioCompeticao` varchar(45) DEFAULT NULL,
  `FimCompeticao` varchar(45) DEFAULT NULL,
  `MatriculaResponsavel` varchar(45) DEFAULT NULL,
  `emailContato` varchar(45) DEFAULT NULL,
  `celularContato` varchar(45) DEFAULT NULL,
  `CEPSenac` varchar(45) DEFAULT NULL,
  `CidadeCompeticao` varchar(45) DEFAULT NULL,
  `UFCompeticao` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Extraindo dados da tabela `competicao`
--

INSERT INTO `competicao` (`idCompeticao`, `NomeCompeticao`, `InicioCompeticao`, `FimCompeticao`, `MatriculaResponsavel`, `emailContato`, `celularContato`, `CEPSenac`, `CidadeCompeticao`, `UFCompeticao`) VALUES
(1, 'Xadrez', '2024-05-22', '2024-06-01', '141.834.654-20', 'lais@gmail.com', '(35) 9 8745-6421', '37200-000', 'Lavras', 'MG'),
(2, 'Boliche', '2024-08-01', '2024-10-01', '141.654.123-45', 'mvm@gmail.com', '(35) 9 8745-6421', '37200-000', 'Lavras', 'MG'),
(3, 'Rinha de Galo', '2024-02-13', '2024-02-29', '402.250.123-92', 'mvm@mail.com', '(12)98745-9012', '21390-123', 'Juazeiro', 'Pará'),
(5, 'nado sincronizado', 'mais tarde', 'depois de mais tarde', '000.000.000.00', 'hericaoomaislindodetds@gmail.com', '40028922', '37200-000', 'Lavras city', 'MG');

-- --------------------------------------------------------

--
-- Estrutura da tabela `quesitos`
--

CREATE TABLE `quesitos` (
  `idquesitos` int(11) NOT NULL,
  `Descricao` varchar(45) DEFAULT NULL,
  `competicaoID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL,
  `Nome` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `celular` varchar(45) DEFAULT NULL,
  `competicao` varchar(45) DEFAULT NULL,
  `TipoUser` varchar(25) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `senhaCripto` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`idUsers`, `Nome`, `email`, `celular`, `competicao`, `TipoUser`, `senha`, `senhaCripto`) VALUES
(2, 'henricão', 'hericaoomaislindodetds@gmail.com', '40028922', 'nado sincronizadp', 'adm', '1234', '81dc9bdb52d04dc20036dbd8313ed055'),
(4, 'Lais Sirilo Novais', 'lais@gmail.com', '(35) 9 8754-6532', 'Boliche', 'ADM', '987654', '6c44e5cd17f0019c64b042e4a745412a'),
(5, 'Eduardo', 'edutoroze@gmail.com', '(44) 99928-8066', 'Melhor Site', 'ADM', 'admin123', '0192023a7bbd73250516f069df18b500'),
(7, 'Jonas Reis', 'jonasreis@outlook.com', '(35) 9 8988-4652', 'Boliche', 'USER', '147258369', 'e40f01afbb1b9ae3dd6747ced5bca532'),
(8, 'marcelo', 'marcelo@mail.com', '(23)98782-9898', 'Rinha de Galo', 'adm', '12345', '827ccb0eea8a706c4c34a16891f84e7b'),
(9, 'marcelo', 'mvm@mail.com', '(35)12123-9890', 'Rinha de Galo', 'adm', '1234', '81dc9bdb52d04dc20036dbd8313ed055'),
(10, 'Make', 'izumimaximo@gmail.com', '(35) 6 6666-6666', 'Rinha de Galo', 'USER', '123', '202cb962ac59075b964b07152d234b70'),
(11, 'educomum', 'educomum@gmail.com', NULL, NULL, 'USER', 'comum', '6d769ecb25444b49111b669de9ec6104'),
(13, 'Rafael', 'rafaelmvb682@gmail.com', NULL, NULL, NULL, '123', NULL),
(14, 'Rafael', '35992356302', 'Boliche', 'adm', 'rafaelmvb682@gmail.com', '123', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Estrutura da tabela `votacao`
--

CREATE TABLE `votacao` (
  `idVotacao` int(11) NOT NULL,
  `IdJurado` int(11) DEFAULT NULL,
  `IdCompeticao` int(11) DEFAULT NULL,
  `QuesitoId` int(11) DEFAULT NULL,
  `Nota` int(11) DEFAULT NULL,
  `CEPSenac` varchar(45) DEFAULT NULL,
  `Cidade` varchar(45) DEFAULT NULL,
  `Estado` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `competicao`
--
ALTER TABLE `competicao`
  ADD PRIMARY KEY (`idCompeticao`);

--
-- Índices para tabela `quesitos`
--
ALTER TABLE `quesitos`
  ADD PRIMARY KEY (`idquesitos`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUsers`);

--
-- Índices para tabela `votacao`
--
ALTER TABLE `votacao`
  ADD PRIMARY KEY (`idVotacao`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `competicao`
--
ALTER TABLE `competicao`
  MODIFY `idCompeticao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `idUsers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
